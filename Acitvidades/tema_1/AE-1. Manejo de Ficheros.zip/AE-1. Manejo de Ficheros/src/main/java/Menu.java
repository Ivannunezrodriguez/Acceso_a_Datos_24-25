import controller.GestorCoches;

public class Menu {
    public static void main(String[] args) {
        GestorCoches gestor = new GestorCoches();
        gestor.menu();
    }
}